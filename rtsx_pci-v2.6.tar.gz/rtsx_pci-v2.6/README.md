This is kernel module for Ralink RT3290 Bluetooth

##Installation
```sh
make
sudo make install
sudo dkms install rtbth/3.9.4
```

This driver is not well maitained. If you have a bugreport, you'd better fork and fix, because neither I nor Realtek pays enough attention on this.
